import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-services',
  imports: [CommonModule],
  templateUrl: './services.component.html',
  styleUrl: './services.component.scss'
})
export class ServicesComponent {

  services = [
    { id: 1, name: 'Web advertising - Basic', description: 'Get your brand noticed with our basic web advertising service', price: "2,500", icon: 'computer' },
    { id: 2, name: 'Web advertising - Pro', description: 'Get your brand noticed with our professional web advertising service.', price: "5,000", icon: 'search' },
    { id: 3, name: 'Web advertising - Premium', description: 'Get your brand noticed with our premium web advertising service', price: "7,500", icon: 'search' },
    // { id: 4, name: 'Social Media Marketing', description: 'Boost your online presence.', price: 25000, icon: 'public' },
    // { id: 5, name: 'Content Writing', description: 'High-quality content services.', price: 15000, icon: 'edit' }
  ];

  constructor(private router: Router) {}

  selectService(serviceId: number) {
    this.router.navigate(['/checkout', serviceId]); // Navigate to checkout with service ID
  }

}
