import { Component, OnInit } from '@angular/core';
// CommonModule
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  imports: [CommonModule],
  styleUrl: './vieworder.component.scss'
})
export class VieworderComponent implements OnInit {
  status: string = 'pending'; // Default state to match original UI

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.status = params['s'] || 'pending';
    });
  }
}

