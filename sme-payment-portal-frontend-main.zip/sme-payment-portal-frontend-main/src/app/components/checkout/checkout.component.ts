import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent {

  constructor(private router: Router) {}
  

  selectedService = {
    name: 'Web advertising - Premium',
    description: 'Get your brand noticed with our premium web advertising service.',      
    price: "7,500"
  };
  userData = { fname: '', lname:'', email: '', phone: '' };
  receiptFile: File | null = null;

  onFileSelected(event: any): void {
    if (event.target.files.length > 0) {
      this.receiptFile = event.target.files[0];
    }
  }

  submitOrder(): void {
    if (!this.userData.fname || !this.userData.lname || !this.userData.email || !this.userData.phone) {
      alert('Please fill in all required fields.');
      return;
    }

    
    const formData = new FormData();
    formData.append('service', JSON.stringify(this.selectedService));
    formData.append('name', this.userData.fname + ' ' + this.userData.lname);
    formData.append('email', this.userData.email);
    formData.append('phone', this.userData.phone);
    // formData.append('receipt', this.receiptFile);
    
    console.log('Order Submitted:', formData);
    this.router.navigate(['/vieworder/SME59475827863']);
  }
}
