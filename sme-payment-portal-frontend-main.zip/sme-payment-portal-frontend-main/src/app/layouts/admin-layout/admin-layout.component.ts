import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-layout',
  imports: [],
  templateUrl: './admin-layout.component.html',
  styleUrl: './admin-layout.component.scss'
})
export class AdminLayoutComponent {

}
