import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Router, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'SMEConnect | Payment Portal';

  isLoading = false; // Global loading state
  delayms = 500; // Delay in ms

  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.isLoading = true; // Start loading
      } 
      if (event instanceof NavigationEnd || event instanceof NavigationError) {
        //Random delay to simulate loading between 500ms to 1.2s
        this.delayms = Math.floor(Math.random() * (1200 - 500 + 1)) + 500;

        setTimeout(() => { 
          this.isLoading = false; // Fake delay (1s) for smooth transition
        }, this.delayms);
      }
    });
  }
}
