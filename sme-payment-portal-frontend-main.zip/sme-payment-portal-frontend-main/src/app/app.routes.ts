import { Routes } from '@angular/router';
import { CheckoutLayoutComponent } from './layouts/checkout-layout/checkout-layout.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { VieworderComponent } from './components/vieworder/vieworder.component';
import { ServicesComponent } from './components/services/services.component';

export const routes: Routes = [
  {path: 'services', component: CheckoutLayoutComponent,
    children: [
        {path: '', component: ServicesComponent}
    ]
  },
  {
    path: 'checkout',
    component: CheckoutLayoutComponent,
    children: [
      { path: ':serviceId', component: CheckoutComponent } // ✅ Checkout with service ID
    ]
  },
  {
    path: 'vieworder',
    component: CheckoutLayoutComponent,
    children: [
      { path: ':orderRef', component: VieworderComponent } // ✅ View order with order ID

    ]
  },
  { path: '**', redirectTo: '/services' } // Default redirect with a sample serviceId
];
